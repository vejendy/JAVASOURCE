package member;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import kr.ac.itschool.entities.Member;

public class MemberGuiActionListener implements ActionListener {
	DefaultTableModel model;
	JTable table; JTextField find ;JTextField id; JTextField name; JTextField password; 
	JTextField phone1; JTextField phone2; JTextField phone3; 
	JTextField post; JTextField addr1; JTextField addr2;
	
	MemberGuiActionListener(DefaultTableModel model, JTable table,JTextField find,JTextField id ,JTextField name,JTextField password,JTextField phone1,
				JTextField phone2,JTextField phone3,JTextField post ,JTextField addr1,JTextField addr2) {
		this.model = model;
		this.table = table;
		this.find  = find;
		this.id = id;
		this.name = name;
		this.password = password;
		this.phone1 = phone1;
		this.phone2 = phone2;
		this.phone3 = phone3;
		this.post = post;
		this.addr1 = addr1;
		this.addr2 = addr2;
	}
		
	@Override
	public void actionPerformed(ActionEvent e) {
		Member data = new Member();
		data.setId( id.getText() );
		data.setName( name.getText() );
		data.setPassword( password.getText() );
		data.setPhone1( phone1.getText() );
		data.setPhone2( phone2.getText() );
		data.setPhone3( phone3.getText() );
		data.setAddr1( addr1.getText() );
		data.setAddr2( addr2.getText() );
		String btntxt = e.getActionCommand();
		if ( btntxt.equals("입력")){
			insertMember( data );
		}
	}
	
	void insertMember( Member data ) {
		System.out.println(data.getId());
		System.out.println(data.getName());	
	}

}
