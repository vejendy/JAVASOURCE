package kr.ac.itschool.practice;

public class MemberInterfaceMain {
	public static void main(String[] args){
		
		MemberImplements obj = new MemberImplements();
		String result = obj.select();
		System.out.println(result);
		
	}	
}
