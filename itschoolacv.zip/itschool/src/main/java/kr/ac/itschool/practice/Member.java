package kr.ac.itschool.practice;

public interface Member {
	public void insert();
	public int update();
	public String select();
	public int delete();
	public void sumMeth();
}
